'''
Created on 1 April , 2020

@author:Brian
'''
from Student import Student
from Student121 import Student121
import fileinput
import matplotlib.pyplot as plt
import sys

studentList = []
        
def displayFile(datafile):
    for line in fileinput.input(datafile):
        sys.stdout.write(line)
        
def displayGraph():
    fig = plt.figure(figsize=(10,8))    # width x height in inches
    ax1 = fig.add_subplot(111)
             
    gradeFeq = {'A':0,'B':0,'C':0,'D':0,'F':0}
                            
    ax1.bar(['A','B','C','D','F'],[4,2,2,0,3])
                    
    ax1.set_xlabel('Grade')
    ax1.set_ylabel('Student Numbers')
    ax1.set_title('Grade Distribution')
    
    plt.show()

def mark1(datafile):
    '''
    read and display error found
    '''
    fileIn = open(datafile, 'r')
    line = fileIn.readline()
            
    while line != '':
        try:
            if Student.numStudent == 0:
                studentList.append(Student121(line))
            else:
                studentRec=line.split('_')
                for e in studentList:
                    if studentRec[0] == e.getStudID():
                        raise ValueError('Repeat student error')
        
                studentList.append(Student121(line))
                        
        except ValueError as valueError:
            sys.stderr.write(str(valueError) + ' : ' + line + '\n')
            sys.stderr.flush()
        
        line = fileIn.readline()
    
    fileIn.close()
    
def mark2():
    '''
    print out all valid data
    '''
    sys.stderr.flush()
    sys.stdout.flush()
    sys.stdout.write('''
Stud ID   Name              CW1 mark  Test mark CW2 mark  Exam mark
===================================================================
''')
    
    for e in studentList:
        print(e)
    sys.stdout.flush()
    
def mark3():
    sys.stderr.flush()
    sys.stdout.flush()
    sys.stdout.write('''
Stud ID   Name              CW1 mark  Test mark CW2 mark  Exam mark  CW mark  Overall
=====================================================================================
''')
    
    for e in studentList:
        print("%65s%10.2f%10.2f"%(e.__str__(),e.getCoursework(),e.overall()))

def mark4():
    sys.stderr.flush()
    sys.stdout.flush()
    sys.stdout.write('''
Stud ID   Name              CW1 mark  Test mark CW2 mark  Exam mark  CW mark  Overall
=====================================================================================
''')

    for e in studentList:
        if e.overall() < 40:
            print("%65s%10.2f%10.2f"%(e.__str__(),e.getCoursework(),e.overall()))
   
def mark5():
    fig = plt.figure(figsize=(10,8))    # width x height in inches
    ax1 = fig.add_subplot(111)
             
    gradeFeq = {'A':0,'B':0,'C':0,'D':0,'F':0}
    
    for e in studentList:
        mark = e.overall()
        if mark > 75:
            gradeFeq['A'] += 1
        elif mark > 65 and mark < 75:
            gradeFeq['B'] += 1
        elif mark > 50 and mark < 65:
            gradeFeq['C'] += 1
        elif mark > 40 and mark < 50:
            gradeFeq['D'] += 1
        else:
            gradeFeq['F'] += 1
                                                  
    ax1.bar(['A','B','C','D','F'],
            [gradeFeq['A'],gradeFeq['B'],gradeFeq['C'],gradeFeq['D'],gradeFeq['F']])
                    
    ax1.set_xlabel('Grade')
    ax1.set_ylabel('Student Numbers')
    ax1.set_title('Grade Distribution')
    
    plt.show()
    
def main():
    instructions = """\nEnter one of the following:
       1 to print the contents of input data file
       2 to print all valid input data
       3 to print all students overall mark 
       4 to print all students whose mark less than 40
       5 to plot distribution of grade
       Q to end \n"""
    
    while True:
        
        sys.stdout.write (instructions)
        sys.stdout.flush()        
        choice = input( "Enter 1 to 5 " ) 
        
        if choice == "1":
            displayFile(sys.argv[1])
        elif choice == "2":
            mark2()
        elif choice == "3":
            mark3()
        elif choice == "4":
            mark4()
        elif choice == "5":
            mark5()
        elif choice == "Q":
            break

    print ("End Grade Processing App")

if __name__ == "__main__":
    try:
      
        displayFile(sys.argv[1])
        sys.stdout.flush()
        mark1(sys.argv[1])
        sys.stderr.flush()
        main()
    
    except IndexError as error:
        sys.stderr.write('Type \"python grade.py filename\" to run program\n')

    except FileNotFoundError as e:
        sys.stderr.write(str(e))

        